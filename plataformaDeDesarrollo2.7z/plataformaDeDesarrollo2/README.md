# plataformaDeDesarrollo2
TP unificacion
El Proyecto se trata sobre un banco; en el programa el Usuario se puede registrarse para ver la información que está necesitando. El usuario puede ver las cajas que tiene vinculado, movimientos, tarjetas, etc. También el usuario tiene el poder de crear, modificar y eliminar la información siempre y cuando cumpla con los requisitos necesarios
