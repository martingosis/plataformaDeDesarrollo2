﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace InterfazTP
{
    public class CajaDeAhorro
    {
        public int id { get; set; }
        public int cbu { get; set; }
        public List<Usuario> titular { get; set; }
        public float saldo { get; set; }
        public List<Movimiento> movimientos { get; set; }


        public CajaDeAhorro()
        {

            titular = new List<Usuario>();

            movimientos = new List<Movimiento>();

        }
    }
}